export const DATA_JSON_URL = "https://triangular-timer.glitch.me/data.json";
export const MODEL_JSON_URL = "https://triangular-timer.glitch.me/model.json";
export const MODEL_META_JSON_URL =
  "https://triangular-timer.glitch.me/model_meta.json";
export const MODEL_WEIGHTS_BIN_URL =
  "https://cdn.glitch.com/7679638e-d60e-450f-bd42-ac4a97b51fab%2Fmodel.weights.bin?v=1578668237816";
